var vidon = true;

var dj = document.getElementById("music");
      
var btn = document.getElementById("rocker");
btn.onclick = function () {
if (vidon === true) {
        document.getElementById("volume").src="assets/OFF.png";
        dj.pause();
        vidon = false;
    } else {
        document.getElementById("volume").src="assets/ON.png";
        dj.play();
        vidon = true;
    }
};