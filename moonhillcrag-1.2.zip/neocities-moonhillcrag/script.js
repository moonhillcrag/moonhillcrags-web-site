//Volume Button

var vidon = true;

const dj = document.getElementById("music");
      
const rock = document.getElementById("rocker");

rock.onclick = function () {
if (vidon === true) {
        document.getElementById("volume").src="assets/OFF.png";
        dj.pause();
        vidon = false;
    } else {
        document.getElementById("volume").src="assets/ON.png";
        dj.play();
        vidon = true;
    }
};

//Post Comment Button

function handleSubmit(event) {
    event.preventDefault();

    const data = new FormData(event.target);

    const value = Object.fromEntries(data.entries());

    console.log({ value });
  }

  const form = document.querySelector('form');
  form.addEventListener('submit', handleSubmit);